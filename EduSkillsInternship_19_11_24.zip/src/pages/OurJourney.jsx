import React from "react";
import Timeline from "../components/common/Timeline";

const OurJourney = () => {
  return (
    <div>
      <Timeline />
    </div>
  );
};

export default OurJourney;
