import React from "react";
import Internship from "../components/Internship";
import InternHero from "../components/InternHero";

const InternshipPage = () => {
  return (
    <div>
        <InternHero/>
      <Internship />
    </div>
  );
};

export default InternshipPage;
