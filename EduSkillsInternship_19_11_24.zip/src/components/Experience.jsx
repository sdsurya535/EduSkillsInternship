import React from 'react'
import ULBannerCards from './cards/ULBannerCards'

const Experience = () => {
  return (
    <div className='flex justify-center'>
        <ULBannerCards/>
    </div>
  )
}

export default Experience