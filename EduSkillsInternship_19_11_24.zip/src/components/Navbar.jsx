import React, { useState } from "react";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);


  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className=" sticky top-0 z-50 border-b border-gray-200 text-custom-blue bg-white" >
      <div className="h-14 mx-auto flex items-center">
        {/* Mobile Menu Button */}
        <button
          className="lg:hidden text-custom-blue focus:outline-none"
          onClick={toggleMenu}
        >
          {isOpen ? (
            <svg
              className="h-6 w-6 transform transition-transform duration-500 rotate-180"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          ) : (
            <svg
              className="h-6 w-6 transform transition-transform duration-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16m-7 6h7"
              />
            </svg>
          )}
        </button>

        {/* Full Menu with transition */}
        <div
          className={`flex-grow justify-center items-center transition-max-height duration-500 ease-in-out ${
            isOpen ? "max-h-screen bg-white p-4 mt-[300px] ml-[-24px] flex items-center" : "max-h-0"
          } overflow-hidden lg:flex lg:max-h-full`}
        >
          <div className="flex flex-col font-[600] lg:flex-row space-y-6 lg:space-y-0 lg:space-x-6 items-center">
            <a href="/" className="hover:text-blue-700 flex items-center">
              Home
            </a>
            <a href="/our-journey" className="hover:text-blue-700 flex items-center">
              Journey
            </a>
            <a href="/internship" className="hover:text-blue-700 flex items-center">
              Internship
            </a>
            <button className="bg-custom-blue hover:bg-blue-700 text-white font-bold py-1 px-4 rounded-full flex items-center">
              Join Now
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

